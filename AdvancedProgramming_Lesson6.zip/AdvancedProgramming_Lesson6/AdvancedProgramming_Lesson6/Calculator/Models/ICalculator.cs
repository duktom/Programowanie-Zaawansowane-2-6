﻿namespace Calculator.Models;

public interface ICalculator
{
    string Calculate(string expression);
}