Na podstawie filmu

https://www.youtube.com/watch?v=AQ4poJaYIN4&ab_channel=LeslawPawlaczyk

Do wykonania modyfikacja projektu 
https://github.com/palles77/WsbAdvancedProgramming/tree/main/AdvancedProgramming_Lesson2

## Ocenianie

1. Ocena dst - wykonanie tłumaczeń dla 2 języków z poprzedniego ćwiczenia oraz strony z polityką prywatności oraz 'O mnie'.
2. Ocena dst plus - wykonanie tłumaczeń dla 3 języków z poprzedniego ćwiczenia oraz strony z polityką prywatności oraz 'O mnie'.
3. Ocena db - wykonanie tłumaczeń dla 4 języków z poprzedniego ćwiczenia oraz strony z polityką prywatności oraz 'O mnie'.
4. Ocena db plus - wykonanie zadanie na ocenę 4 oraz wykonanie poprawienie stylizacji strony na inną kolorystykę i schemat bootstrap.
5. Ocena bdb - wykonanie zadanie na ocenę 4.5 oraz dodanie opcji zmiany kolorystyki strony poprzez umieszczenie combo-box na górze.

## Sprawozdania

Sprawozdania wysłać na adres leslaw dot pawlaczyk at chorzow dot wsb dot pl
Sprawozdania wysłać w postaci linku do repo na GitHub. 
W mejlu podać nr albumu.
Sprawozdania wysłać do 2023/09/15.

## Ostatnie zmiany

2023/03/22
